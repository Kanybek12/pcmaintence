package kumtor.kg.PCMaintanence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcMaintanenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
