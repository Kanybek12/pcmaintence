export default {
  failed: 'ишке ашпай калды',
  success: 'ийгиликтүү'
}
