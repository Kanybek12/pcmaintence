import enUS from './en-US'
import ruRU from './ru-RU'
import kgKG from './kg-KG'

export default {
  'en-US': enUS,
  'ru-RU': ruRU,
  'kg-KG': kgKG
}
